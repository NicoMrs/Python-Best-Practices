from ..model import Model
from .stream import Stream

if __name__ == '__main__':
    print("SetUp a stream for model")
    model = Model()
    stream = Stream()
