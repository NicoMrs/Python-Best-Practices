# utils.py
from ..utils import run_from


@run_from
def helper_func():
    pass
