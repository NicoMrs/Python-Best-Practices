# main.py

import app

if __name__ == '__main__':
    m = app.Model()
    s = app.Stream()
