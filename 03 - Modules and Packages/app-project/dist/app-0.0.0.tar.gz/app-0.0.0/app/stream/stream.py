# stream.py
__all__ = ["Stream"]
class Console:
    pass


class Stream:
    def __init__(self):
        print("Stream setting up ...")